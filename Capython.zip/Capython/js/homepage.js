// scroll to footer function
document.querySelector('a[href="#footer"]').addEventListener('click', function(e) {
    e.preventDefault();
    document.getElementById('footer').scrollIntoView();
});